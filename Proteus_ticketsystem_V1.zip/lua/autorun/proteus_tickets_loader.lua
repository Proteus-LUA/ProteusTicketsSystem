local files = {
	shared = {
		"proteus_tickets/sh_config.lua",
		"proteus_tickets/sh_util.lua",
	},
	server = {
		"proteus_tickets/sv_storage.lua",
		"proteus_tickets/sv_tickets.lua",
		"proteus_tickets/sv_webhook.lua",
		"proteus_tickets/sv_net.lua",
		"proteus_tickets/sv_chat.lua",
	},
	client = {
		"proteus_tickets/cl_notify.lua",
		"proteus_tickets/cl_panel.lua",
	},
}

if SERVER then
	for _, path in ipairs(files.shared) do
		AddCSLuaFile(path)
	end
	for _, path in ipairs(files.client) do
		AddCSLuaFile(path)
	end
end

for _, path in ipairs(files.shared) do
	include(path)
end

if SERVER then
	for _, path in ipairs(files.server) do
		include(path)
	end
else
	for _, path in ipairs(files.client) do
		include(path)
	end
end
