PROTEUS_TICKETS = PROTEUS_TICKETS or {}

local Config = PROTEUS_TICKETS.Config
local Tickets = PROTEUS_TICKETS.Tickets
local Net = {}
PROTEUS_TICKETS.Net = Net

util.AddNetworkString("proteus_tickets_notice")
util.AddNetworkString("proteus_tickets_alert")
util.AddNetworkString("proteus_tickets_panel")
util.AddNetworkString("proteus_tickets_action")
util.AddNetworkString("proteus_tickets_refresh")
util.AddNetworkString("proteus_tickets_player_menu")
util.AddNetworkString("proteus_tickets_submit")
util.AddNetworkString("proteus_tickets_jump")

function Net.Notice(ply, message, color)
	if not IsValid(ply) then return end
	net.Start("proteus_tickets_notice")
	net.WriteString(message)
	net.WriteColor(color or Config.AccentColor)
	net.Send(ply)
end

function Net.GetOnlineStaff()
	local staff = {}
	for _, ply in ipairs(player.GetAll()) do
		if PROTEUS_TICKETS.IsStaff(ply) then
			staff[#staff + 1] = ply
		end
	end
	return staff
end

function Net.AlertStaff(ticket)
	local staff = Net.GetOnlineStaff()
	if #staff == 0 then return end
	net.Start("proteus_tickets_alert")
	net.WriteUInt(ticket.id, 32)
	net.WriteString(ticket.requesterName)
	net.WriteString(ticket.issue or ticket.message or "Ticket")
	net.Send(staff)
end

function Net.OpenPlayerMenu(ply, prefill)
	if not IsValid(ply) then return end
	net.Start("proteus_tickets_player_menu")
	net.WriteString(prefill or "")
	net.Send(ply)
end

function Net.SendPanel(ply, doOpen, selectedId)
	if not IsValid(ply) then return end
	net.Start("proteus_tickets_panel")
	net.WriteBool(doOpen)
	net.WriteString(util.TableToJSON(Tickets.SerializeList()))
	net.WriteUInt(selectedId or 0, 32)
	net.Send(ply)
end

function Net.BroadcastPanelUpdate()
	local staff = Net.GetOnlineStaff()
	if #staff == 0 then return end
	net.Start("proteus_tickets_panel")
	net.WriteBool(false)
	net.WriteString(util.TableToJSON(Tickets.SerializeList()))
	net.WriteUInt(0, 32)
	net.Send(staff)
end

function Net.OpenAdminPanel(ply)
	if not PROTEUS_TICKETS.IsStaff(ply) then
		Net.Notice(ply, "Tu n'as pas accès au panel des tickets.", Config.StatusColors.open)
		return
	end
	Net.SendPanel(ply, true, 0)
end

net.Receive("proteus_tickets_refresh", function(_, ply)
	if not PROTEUS_TICKETS.IsStaff(ply) then return end
	local removed = Tickets.RemoveClosed and Tickets.RemoveClosed() or 0
	Net.SendPanel(ply, false, 0)
	if removed > 0 then
		Net.Notice(ply, removed .. " ticket(s) fermé(s) retiré(s) du menu.", Config.AccentColor)
	end
end)

net.Receive("proteus_tickets_submit", function(_, ply)
	local data = {
		issue = net.ReadString(),
		situation = net.ReadString(),
		involved = net.ReadString(),
		extra = net.ReadString(),
	}

	local ok, err, ticket = Tickets.Create(ply, data)
	if not ok then
		Net.Notice(ply, err, Config.StatusColors.open)
		return
	end

	Net.Notice(ply, "Ticket #" .. ticket.id .. " ouvert. Un membre du staff va te répondre.", Config.StatusColors.closed)
	Net.AlertStaff(ticket)
	Net.BroadcastPanelUpdate()

	if PROTEUS_TICKETS.Webhook and PROTEUS_TICKETS.Webhook.OnCreate then
		PROTEUS_TICKETS.Webhook.OnCreate(ticket)
	end
end)

net.Receive("proteus_tickets_jump", function(_, ply)
	if not PROTEUS_TICKETS.IsStaff(ply) then return end
	local id = net.ReadUInt(32)
	if id == 0 or not Tickets.Get(id) then return end
	Net.SendPanel(ply, true, id)
end)

net.Receive("proteus_tickets_action", function(_, ply)
	if not PROTEUS_TICKETS.IsStaff(ply) then return end

	local action = net.ReadString()
	local id = net.ReadUInt(32)
	local text = net.ReadString()

	local ok, err

	if action == "claim" then
		ok, err = Tickets.Claim(ply, id)
	elseif action == "goto" then
		ok, err = Tickets.GotoRequester(ply, id)
	elseif action == "bring" then
		ok, err = Tickets.BringRequester(ply, id)
	elseif action == "reply" then
		ok, err = Tickets.Reply(ply, id, text, true)
	elseif action == "close" then
		ok, err = Tickets.Close(ply, id, text, true)
	else
		return
	end

	if not ok then
		Net.Notice(ply, err or "Action impossible.", Config.StatusColors.open)
		return
	end

	local ticket = Tickets.Get(id)
	local target = ticket and PROTEUS_TICKETS.FindPlayer(ticket.requester)

	if action == "claim" then
		Net.Notice(ply, "Tu as pris en charge le ticket #" .. id .. ".")
		if IsValid(target) then
			Net.Notice(target, "Ton ticket #" .. id .. " est pris en charge par " .. ply:Nick() .. ".", Config.StatusColors.claimed)
		end
	elseif action == "goto" then
		Net.Notice(ply, "Téléportation vers le joueur du ticket #" .. id .. ".")
	elseif action == "bring" then
		Net.Notice(ply, "Joueur du ticket #" .. id .. " amené vers toi.")
		if IsValid(target) then
			Net.Notice(target, ply:Nick() .. " t'a amené pour ton ticket #" .. id .. ".", Config.StatusColors.claimed)
		end
	elseif action == "reply" then
		Net.Notice(ply, "Réponse envoyée sur le ticket #" .. id .. ".")
		if IsValid(target) then
			Net.Notice(target, ply:Nick() .. " a répondu à ton ticket #" .. id .. " : " .. text, Config.StatusColors.claimed)
		end
	elseif action == "close" then
		Net.Notice(ply, "Ticket #" .. id .. " fermé.", Config.StatusColors.closed)
		if IsValid(target) then
			Net.Notice(target, "Ton ticket #" .. id .. " a été fermé : " .. (ticket.closeReason or ""), Config.StatusColors.closed)
		end
	end

	Net.BroadcastPanelUpdate()
end)
