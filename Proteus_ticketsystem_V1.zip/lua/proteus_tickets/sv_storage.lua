PROTEUS_TICKETS = PROTEUS_TICKETS or {}
PROTEUS_TICKETS.Active = PROTEUS_TICKETS.Active or {}
PROTEUS_TICKETS.NextId = PROTEUS_TICKETS.NextId or 1

local Config = PROTEUS_TICKETS.Config
local Storage = {}
PROTEUS_TICKETS.Storage = Storage

local function ensureFolder()
	if not file.IsDir(Config.DataFolder, "DATA") then
		file.CreateDir(Config.DataFolder)
	end
end

local function timestamp()
	return os.date("%Y-%m-%d %H:%M:%S")
end

function Storage.AppendLog(line)
	ensureFolder()
	file.Append(Config.LogFile, "[" .. timestamp() .. "] " .. line .. "\n")
end

function Storage.ResetLog()
	ensureFolder()
	file.Write(Config.LogFile, "[" .. timestamp() .. "] LOG RESET\n")
end

function Storage.SaveActive()
	ensureFolder()
	local payload = {
		nextId = PROTEUS_TICKETS.NextId,
		tickets = PROTEUS_TICKETS.Active,
	}
	file.Write(Config.ActiveFile, util.TableToJSON(payload, true))
end

local function loadActive()
	if not file.Exists(Config.ActiveFile, "DATA") then return end
	local raw = file.Read(Config.ActiveFile, "DATA")
	if not raw or raw == "" then return end
	local data = util.JSONToTable(raw)
	if not data then return end
	PROTEUS_TICKETS.Active = data.tickets or {}
	PROTEUS_TICKETS.NextId = data.nextId or 1
end

local function readMeta()
	if not file.Exists(Config.MetaFile, "DATA") then return { reboots = 0 } end
	local raw = file.Read(Config.MetaFile, "DATA")
	local data = raw and util.JSONToTable(raw)
	if not data then return { reboots = 0 } end
	return data
end

local function writeMeta(meta)
	ensureFolder()
	file.Write(Config.MetaFile, util.TableToJSON(meta, true))
end

local function purgeHandledTickets()
	local kept = {}
	for _, ticket in ipairs(PROTEUS_TICKETS.Active) do
		if ticket.status == "open" then
			kept[#kept + 1] = ticket
		end
	end
	PROTEUS_TICKETS.Active = kept
end

function Storage.Boot()
	ensureFolder()
	loadActive()

	local meta = readMeta()
	meta.reboots = (meta.reboots or 0) + 1

	if meta.reboots >= Config.RebootResetThreshold then
		Storage.AppendLog("REBOOT THRESHOLD REACHED (" .. meta.reboots .. ") FULL RESET")
		Storage.ResetLog()
		purgeHandledTickets()
		meta.reboots = 0
		Storage.AppendLog("Reset done, handled tickets cleared")
	end

	writeMeta(meta)
	Storage.SaveActive()
	Storage.AppendLog("Server boot, " .. #PROTEUS_TICKETS.Active .. " active ticket(s) loaded")
end

function Storage.OnShutdown()
	local pending = 0
	for _, ticket in ipairs(PROTEUS_TICKETS.Active) do
		if ticket.status ~= "closed" then
			pending = pending + 1
			Storage.AppendLog("PENDING #" .. ticket.id .. " [" .. ticket.status .. "] " .. ticket.requesterName .. " : " .. ticket.message)
		end
	end
	Storage.AppendLog("SERVER SHUTDOWN, " .. pending .. " pending ticket(s) saved")
	Storage.SaveActive()
end

hook.Add("ShutDown", "proteus_tickets_shutdown", function()
	Storage.OnShutdown()
end)

Storage.Boot()
