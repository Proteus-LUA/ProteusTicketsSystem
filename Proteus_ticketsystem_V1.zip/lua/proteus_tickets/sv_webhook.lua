PROTEUS_TICKETS = PROTEUS_TICKETS or {}

local Config = PROTEUS_TICKETS.Config
local Storage = PROTEUS_TICKETS.Storage
local Webhook = {}
PROTEUS_TICKETS.Webhook = Webhook

local function dispatch(embed)
	local cfg = Config.Webhook
	if not cfg.Enabled then return end
	if not cfg.Url or cfg.Url == "" then return end

	local payload = {
		username = cfg.Username,
		embeds = { embed },
	}

	HTTP({
		url = cfg.Url,
		method = "POST",
		type = "application/json",
		body = util.TableToJSON(payload),
		success = function(code)
			if code >= 200 and code < 300 then return end
			Storage.AppendLog("WEBHOOK response code " .. tostring(code))
		end,
		failed = function(reason)
			Storage.AppendLog("WEBHOOK failed : " .. tostring(reason))
		end,
	})
end

local function buildEmbed(ticket, title, note)
	return {
		title = title,
		description = note,
		color = Config.Webhook.EmbedColor,
		fields = {
			{ name = "Ticket", value = "#" .. ticket.id, inline = true },
			{ name = "Joueur", value = ticket.requesterName, inline = true },
			{ name = "Statut", value = PROTEUS_TICKETS.StatusLabel(ticket.status), inline = true },
			{ name = "Message", value = string.sub(ticket.message, 1, 1000), inline = false },
		},
		footer = { text = "SteamID " .. ticket.requester },
	}
end

function Webhook.OnCreate(ticket)
	local cfg = Config.Webhook
	if not cfg.Enabled or not cfg.NotifyOnCreate then return end
	dispatch(buildEmbed(ticket, "Nouveau ticket #" .. ticket.id, "Un ticket vient d'être ouvert en jeu."))
end

local function scanStaleTickets()
	local cfg = Config.Webhook
	local now = os.time()

	for _, ticket in ipairs(PROTEUS_TICKETS.Active) do
		if ticket.status == "open" then
			local age = now - ticket.createdAt
			if age >= cfg.StaleSeconds then
				local due = false
				if not ticket.webhookNotified then
					due = true
				elseif cfg.RenotifyInterval > 0 and (now - (ticket.webhookLast or 0)) >= cfg.RenotifyInterval then
					due = true
				end

				if due then
					ticket.webhookNotified = true
					ticket.webhookLast = now
					local note = "Ce ticket attend une réponse depuis " .. PROTEUS_TICKETS.FormatDuration(age) .. ". Un membre du staff est demandé en jeu."
					dispatch(buildEmbed(ticket, "Ticket #" .. ticket.id .. " sans réponse", note))
					Storage.AppendLog("WEBHOOK stale alert sent for #" .. ticket.id)
					Storage.SaveActive()
				end
			end
		end
	end
end

if Config.Webhook.Enabled then
	timer.Create("proteus_tickets_webhook_scan", math.max(5, Config.Webhook.CheckInterval), 0, scanStaleTickets)
end
