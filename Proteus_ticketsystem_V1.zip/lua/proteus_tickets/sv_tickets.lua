PROTEUS_TICKETS = PROTEUS_TICKETS or {}

local Config = PROTEUS_TICKETS.Config
local Storage = PROTEUS_TICKETS.Storage
local Tickets = {}
PROTEUS_TICKETS.Tickets = Tickets

local cooldowns = {}

function Tickets.Get(id)
	for _, ticket in ipairs(PROTEUS_TICKETS.Active) do
		if ticket.id == id then return ticket end
	end
	return nil
end

function Tickets.GetActiveByPlayer(steamid)
	for _, ticket in ipairs(PROTEUS_TICKETS.Active) do
		if ticket.requester == steamid and ticket.status ~= "closed" then
			return ticket
		end
	end
	return nil
end

function Tickets.Serialize(ticket)
	return {
		id = ticket.id,
		requester = ticket.requester,
		requesterName = ticket.requesterName,
		message = ticket.message,
		issue = ticket.issue,
		situation = ticket.situation,
		involved = ticket.involved,
		extra = ticket.extra,
		status = ticket.status,
		claimedBy = ticket.claimedBy,
		claimedByName = ticket.claimedByName,
		closeReason = ticket.closeReason,
		createdAt = ticket.createdAt,
		ageSeconds = os.time() - ticket.createdAt,
		online = IsValid(PROTEUS_TICKETS.FindPlayer(ticket.requester)),
		replies = ticket.replies,
	}
end

function Tickets.SerializeList()
	local list = {}
	for _, ticket in ipairs(PROTEUS_TICKETS.Active) do
		list[#list + 1] = Tickets.Serialize(ticket)
	end
	return list
end


function Tickets.RemoveClosed()
	local kept = {}
	local removed = 0
	for _, ticket in ipairs(PROTEUS_TICKETS.Active) do
		if ticket.status ~= "closed" then
			kept[#kept + 1] = ticket
		else
			removed = removed + 1
		end
	end
	if removed > 0 then
		PROTEUS_TICKETS.Active = kept
		Storage.SaveActive()
		Storage.AppendLog("REFRESH CLEANUP removed " .. removed .. " closed ticket(s)")
	end
	return removed
end

function Tickets.Create(ply, data)
	local issue
	local situation
	local involved
	local extra
	local message

	if istable(data) then
		issue = string.Trim(data.issue or "")
		situation = string.Trim(data.situation or "")
		involved = string.Trim(data.involved or "")
		extra = string.Trim(data.extra or "")
		message = issue .. "\n\n" .. situation
		if involved ~= "" then
			message = message .. "\n\nPersonne impliquée / SteamID : " .. involved
		end
		if extra ~= "" then
			message = message .. "\n\nInformations supplémentaires : " .. extra
		end
	else
		issue = string.Trim(data or "")
		situation = issue
		involved = ""
		extra = ""
		message = issue
	end

	message = string.Trim(message or "")
	if issue == "" or situation == "" then
		return false, "Le problème et la description sont obligatoires."
	end
	if message == "" then
		return false, "Ton message est vide."
	end
	if #message > Config.MaxMessageLength then
		message = string.sub(message, 1, Config.MaxMessageLength)
	end
	if #issue > Config.MaxFieldLength then
		issue = string.sub(issue, 1, Config.MaxFieldLength)
	end
	if #situation > Config.MaxSituationLength then
		situation = string.sub(situation, 1, Config.MaxSituationLength)
	end
	if #involved > Config.MaxFieldLength then
		involved = string.sub(involved, 1, Config.MaxFieldLength)
	end
	if #extra > Config.MaxSituationLength then
		extra = string.sub(extra, 1, Config.MaxSituationLength)
	end

	local sid = ply:SteamID64()

	if Config.OnePerPlayer and Tickets.GetActiveByPlayer(sid) then
		return false, "Tu as déjà un ticket en cours."
	end

	local last = cooldowns[sid]
	if last and (CurTime() - last) < Config.CooldownSeconds then
		local wait = math.ceil(Config.CooldownSeconds - (CurTime() - last))
		return false, "Patiente " .. wait .. "s avant de rouvrir un ticket."
	end
	cooldowns[sid] = CurTime()

	local ticket = {
		id = PROTEUS_TICKETS.NextId,
		requester = sid,
		requesterName = ply:Nick(),
		message = message,
		issue = issue,
		situation = situation,
		involved = involved,
		extra = extra,
		status = "open",
		claimedBy = nil,
		claimedByName = nil,
		claimedAt = nil,
		closeReason = nil,
		closedAt = nil,
		createdAt = os.time(),
		webhookNotified = false,
		webhookLast = 0,
		replies = {},
	}

	PROTEUS_TICKETS.NextId = PROTEUS_TICKETS.NextId + 1
	PROTEUS_TICKETS.Active[#PROTEUS_TICKETS.Active + 1] = ticket

	Storage.SaveActive()
	Storage.AppendLog("CREATED #" .. ticket.id .. " by " .. ticket.requesterName .. " (" .. sid .. ") : " .. message)

	return true, nil, ticket
end

function Tickets.Claim(admin, id)
	local ticket = Tickets.Get(id)
	if not ticket then return false, "Ticket introuvable." end
	if ticket.status == "closed" then return false, "Ce ticket est fermé." end
	if ticket.status == "claimed" then
		return false, "Déjà pris en charge par " .. (ticket.claimedByName or "un staff") .. "."
	end

	ticket.status = "claimed"
	ticket.claimedBy = admin:SteamID64()
	ticket.claimedByName = admin:Nick()
	ticket.claimedAt = os.time()

	Storage.SaveActive()
	Storage.AppendLog("CLAIMED #" .. id .. " by " .. ticket.claimedByName)
	return true, nil, ticket
end

function Tickets.Reply(author, id, text, isStaff)
	local ticket = Tickets.Get(id)
	if not ticket then return false, "Ticket introuvable." end
	if ticket.status == "closed" then return false, "Ce ticket est fermé." end

	text = string.Trim(text or "")
	if text == "" then return false, "Réponse vide." end
	if #text > Config.MaxReplyLength then
		text = string.sub(text, 1, Config.MaxReplyLength)
	end

	if isStaff and ticket.status == "open" then
		ticket.status = "claimed"
		ticket.claimedBy = author:SteamID64()
		ticket.claimedByName = author:Nick()
		ticket.claimedAt = os.time()
	end

	ticket.replies[#ticket.replies + 1] = {
		author = author:SteamID64(),
		authorName = author:Nick(),
		staff = isStaff and true or false,
		text = text,
		time = os.time(),
	}

	Storage.SaveActive()
	Storage.AppendLog("REPLY #" .. id .. (isStaff and " [staff] " or " [player] ") .. author:Nick() .. " : " .. text)
	return true, nil, ticket
end

function Tickets.Close(closer, id, reason, byStaff)
	local ticket = Tickets.Get(id)
	if not ticket then return false, "Ticket introuvable." end
	if ticket.status == "closed" then return false, "Ce ticket est déjà fermé." end

	reason = string.Trim(reason or "")
	if reason == "" then
		reason = byStaff and "Fermé par le staff" or "Fermé par le joueur"
	end

	ticket.status = "closed"
	ticket.closeReason = reason
	ticket.closedAt = os.time()
	ticket.closedBy = IsValid(closer) and closer:SteamID64() or "system"
	ticket.closedByName = IsValid(closer) and closer:Nick() or "Système"

	Storage.SaveActive()
	Storage.AppendLog("CLOSED #" .. id .. " by " .. ticket.closedByName .. " : " .. reason)
	return true, nil, ticket
end

function Tickets.GotoRequester(admin, id)
	local ticket = Tickets.Get(id)
	if not ticket then return false, "Ticket introuvable." end
	local target = PROTEUS_TICKETS.FindPlayer(ticket.requester)
	if not IsValid(target) then return false, "Le joueur n'est plus connecté." end
	admin:SetPos(target:GetPos() + Vector(0, 0, 8))
	return true, nil, ticket
end

function Tickets.BringRequester(admin, id)
	local ticket = Tickets.Get(id)
	if not ticket then return false, "Ticket introuvable." end
	local target = PROTEUS_TICKETS.FindPlayer(ticket.requester)
	if not IsValid(target) then return false, "Le joueur n'est plus connecté." end
	target:SetPos(admin:GetPos() + admin:GetForward() * 64 + Vector(0, 0, 8))
	return true, nil, ticket
end
