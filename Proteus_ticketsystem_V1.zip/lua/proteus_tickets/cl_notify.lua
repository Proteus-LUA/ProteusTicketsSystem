PROTEUS_TICKETS = PROTEUS_TICKETS or {}

local Config = PROTEUS_TICKETS.Config

net.Receive("proteus_tickets_notice", function()
	local message = net.ReadString()
	local color = net.ReadColor()
	chat.AddText(Config.TagColor, Config.ChatTag .. " ", color, message)
end)

net.Receive("proteus_tickets_alert", function()
	local id = net.ReadUInt(32)
	local who = net.ReadString()
	local message = net.ReadString()

	surface.PlaySound(Config.NotifySound)
	chat.AddText(Config.StatusColors.open, Config.ChatTag .. " ", color_white, "Nouveau ticket #" .. id .. " de ", Config.AccentColor, who, color_white, " : " .. message)
	chat.AddText(Config.StatusColors.claimed, "Tape " .. Config.AdminCommand .. " pour ouvrir le panel.")
end)
