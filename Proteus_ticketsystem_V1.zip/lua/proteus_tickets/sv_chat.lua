PROTEUS_TICKETS = PROTEUS_TICKETS or {}

local Config = PROTEUS_TICKETS.Config
local Tickets = PROTEUS_TICKETS.Tickets
local Net = PROTEUS_TICKETS.Net

local function showStatus(ply)
	local ticket = Tickets.GetActiveByPlayer(ply:SteamID64())
	if not ticket then
		Net.OpenPlayerMenu(ply, "")
		return
	end

	local age = PROTEUS_TICKETS.FormatDuration(os.time() - ticket.createdAt)
	Net.Notice(ply, "Ticket #" .. ticket.id .. ", statut : " .. PROTEUS_TICKETS.StatusLabel(ticket.status) .. ", ouvert depuis " .. age .. ".")

	if ticket.claimedByName then
		Net.Notice(ply, "Pris en charge par : " .. ticket.claimedByName)
	end

	for _, reply in ipairs(ticket.replies) do
		local who = reply.staff and ("[Staff] " .. reply.authorName) or reply.authorName
		Net.Notice(ply, who .. " : " .. reply.text)
	end
end

local function closeOwnTicket(ply)
	local ticket = Tickets.GetActiveByPlayer(ply:SteamID64())
	if not ticket then
		Net.Notice(ply, "Tu n'as aucun ticket à fermer.", Config.StatusColors.open)
		return
	end

	local ok, err = Tickets.Close(ply, ticket.id, "Fermé par le joueur", false)
	if not ok then
		Net.Notice(ply, err, Config.StatusColors.open)
		return
	end

	Net.Notice(ply, "Ton ticket #" .. ticket.id .. " a été fermé.", Config.StatusColors.closed)
	for _, staff in ipairs(Net.GetOnlineStaff()) do
		Net.Notice(staff, ply:Nick() .. " a fermé son ticket #" .. ticket.id .. ".")
	end
	Net.BroadcastPanelUpdate()
end

local function replyOwnTicket(ply, text)
	local ticket = Tickets.GetActiveByPlayer(ply:SteamID64())
	if not ticket then
		Net.Notice(ply, "Tu n'as aucun ticket en cours.", Config.StatusColors.open)
		return
	end

	local ok, err = Tickets.Reply(ply, ticket.id, text, false)
	if not ok then
		Net.Notice(ply, err, Config.StatusColors.open)
		return
	end

	Net.Notice(ply, "Réponse ajoutée à ton ticket #" .. ticket.id .. ".")

	local claimer = ticket.claimedBy and PROTEUS_TICKETS.FindPlayer(ticket.claimedBy)
	if IsValid(claimer) then
		Net.Notice(claimer, ply:Nick() .. " a répondu au ticket #" .. ticket.id .. " : " .. text, Config.StatusColors.claimed)
	else
		for _, staff in ipairs(Net.GetOnlineStaff()) do
			Net.Notice(staff, ply:Nick() .. " a répondu au ticket #" .. ticket.id .. ".")
		end
	end
	Net.BroadcastPanelUpdate()
end

local function openTicket(ply, message)
	local ok, err, ticket = Tickets.Create(ply, message)
	if not ok then
		Net.Notice(ply, err, Config.StatusColors.open)
		return
	end

	Net.Notice(ply, "Ticket #" .. ticket.id .. " ouvert. Un membre du staff va te répondre.", Config.StatusColors.closed)
	Net.AlertStaff(ticket)
	Net.BroadcastPanelUpdate()

	if PROTEUS_TICKETS.Webhook and PROTEUS_TICKETS.Webhook.OnCreate then
		PROTEUS_TICKETS.Webhook.OnCreate(ticket)
	end
end

local function handlePlayerCommand(ply, rest)
	rest = string.Trim(rest)
	if rest == "" then
		Net.OpenPlayerMenu(ply, "")
		return
	end

	local parts = string.Explode(" ", rest)
	local verb = string.lower(parts[1] or "")

	if verb == "close" then
		closeOwnTicket(ply)
		return
	end

	if verb == "reply" then
		replyOwnTicket(ply, string.Trim(string.sub(rest, #parts[1] + 1)))
		return
	end

	Net.OpenPlayerMenu(ply, rest)
end

hook.Add("PlayerSay", "proteus_tickets_chat", function(ply, text)
	local trimmed = string.Trim(text)
	local lower = string.lower(trimmed)

	if lower == string.lower(Config.AdminCommand) then
		PROTEUS_TICKETS.Net.OpenAdminPanel(ply)
		return ""
	end

	local playerCmd = string.lower(Config.PlayerCommand)

	if lower == playerCmd then
		handlePlayerCommand(ply, "")
		return ""
	end

	if string.sub(lower, 1, #playerCmd + 1) == playerCmd .. " " then
		handlePlayerCommand(ply, string.sub(trimmed, #playerCmd + 2))
		return ""
	end
end)
