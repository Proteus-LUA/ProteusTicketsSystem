PROTEUS_TICKETS = PROTEUS_TICKETS or {}
PROTEUS_TICKETS.Config = PROTEUS_TICKETS.Config or {}

local Config = PROTEUS_TICKETS.Config

Config.PlayerCommand = "!ticket"
Config.AdminCommand = "!tickets"

Config.CooldownSeconds = 60
Config.MaxMessageLength = 1200
Config.MaxFieldLength = 160
Config.MaxSituationLength = 700
Config.MaxReplyLength = 300
Config.OnePerPlayer = true

Config.AdminGroups = {
	["admin"] = true,
	["superadmin"] = true,
	["moderator"] = true,
}
Config.AllowIsAdminFallback = true

Config.RebootResetThreshold = 4

Config.DataFolder = "proteus_tickets"
Config.ActiveFile = "proteus_tickets/active.json"
Config.LogFile = "proteus_tickets/logs.txt"
Config.MetaFile = "proteus_tickets/meta.json"

Config.ChatTag = "[Tickets]"
Config.NotifySound = "buttons/button15.wav"

Config.Webhook = {
	Enabled = false,
	Url = "https://discord.com/api/webhooks/1505727229777154140/2jvpSm86nr8Bb4bI8qeVaaj2TVllFqEMQWX97m2ghJTp755qj5xSUj8RHjGHMhxgmL-0",
	Username = "Proteus Tickets",
	NotifyOnCreate = false,
	StaleSeconds = 1,
	CheckInterval = 30,
	RenotifyInterval = 0,
	EmbedColor = 15158332,
}

Config.AccentColor = Color(52, 152, 219)
Config.TagColor = Color(52, 152, 219)

Config.StatusColors = {
	open = Color(231, 76, 60),
	claimed = Color(241, 196, 15),
	closed = Color(46, 204, 113),
}
