PROTEUS_TICKETS = PROTEUS_TICKETS or {}

function PROTEUS_TICKETS.IsStaff(ply)
	if not IsValid(ply) then return false end
	local Config = PROTEUS_TICKETS.Config
	if Config.AdminGroups[ply:GetUserGroup()] then return true end
	if Config.AllowIsAdminFallback and ply:IsAdmin() then return true end
	return false
end

function PROTEUS_TICKETS.FindPlayer(steamid64)
	for _, ply in ipairs(player.GetAll()) do
		if ply:SteamID64() == steamid64 then
			return ply
		end
	end
	return nil
end

function PROTEUS_TICKETS.StatusLabel(status)
	if status == "open" then return "Ouvert" end
	if status == "claimed" then return "Pris en charge" end
	if status == "closed" then return "Fermé" end
	return tostring(status)
end

function PROTEUS_TICKETS.FormatDuration(seconds)
	seconds = math.max(0, math.floor(tonumber(seconds) or 0))
	local hours = math.floor(seconds / 3600)
	local minutes = math.floor((seconds % 3600) / 60)
	local rest = seconds % 60
	if hours > 0 then
		return string.format("%dh %dmin", hours, minutes)
	end
	if minutes > 0 then
		return string.format("%dmin %ds", minutes, rest)
	end
	return string.format("%ds", rest)
end
