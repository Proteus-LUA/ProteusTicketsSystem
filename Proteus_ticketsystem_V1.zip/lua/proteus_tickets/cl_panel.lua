PROTEUS_TICKETS = PROTEUS_TICKETS or {}

local Config = PROTEUS_TICKETS.Config

surface.CreateFont("ProteusTickets.Title", {font = "Roboto", size = 24, weight = 800})
surface.CreateFont("ProteusTickets.Header", {font = "Roboto", size = 18, weight = 800})
surface.CreateFont("ProteusTickets.Text", {font = "Roboto", size = 15, weight = 500})
surface.CreateFont("ProteusTickets.Small", {font = "Roboto", size = 13, weight = 500})
surface.CreateFont("ProteusTickets.FormLabel", {font = "Roboto", size = 16, weight = 900})
surface.CreateFont("ProteusTickets.RowTitle", {font = "Roboto", size = 15, weight = 800})
surface.CreateFont("ProteusTickets.RowSmall", {font = "Roboto", size = 12, weight = 500})

local THEME = {
	bg = Color(24, 24, 24),
	header = Color(18, 18, 18),
	panel = Color(31, 31, 31),
	panel2 = Color(38, 38, 38),
	panel3 = Color(28, 28, 28),
	line = Color(55, 55, 55),
	text = Color(235, 235, 235),
	dim = Color(165, 165, 165),
	black = Color(10, 10, 10, 245),
	field = Color(20, 20, 20),
	button = Color(44, 44, 44),
	buttonHover = Color(58, 58, 58)
}

local state = {
	data = {},
	selected = nil,
	frame = nil,
	playerFrame = nil,
	lastTarget = 0,
}

local function findTicket(id)
	for _, ticket in ipairs(state.data) do
		if ticket.id == id then return ticket end
	end
	return nil
end

local function sendAction(action, id, text)
	if not id then return end
	net.Start("proteus_tickets_action")
	net.WriteString(action)
	net.WriteUInt(id, 32)
	net.WriteString(text or "")
	net.SendToServer()
end

local function sendJump(id)
	net.Start("proteus_tickets_jump")
	net.WriteUInt(id or 0, 32)
	net.SendToServer()
end

local function paintBox(color, radius)
	return function(_, w, h)
		draw.RoundedBox(radius or 8, 0, 0, w, h, color)
	end
end

local function brighten(c, amount)
	return Color(math.min(c.r + amount, 255), math.min(c.g + amount, 255), math.min(c.b + amount, 255), c.a)
end

local function styleButton(btn, baseColor, radius)
	btn:SetFont("ProteusTickets.Text")
	btn:SetTextColor(color_white)
	btn.Paint = function(self, w, h)
		local c = baseColor
		if not self:IsEnabled() then
			c = Color(65, 65, 65)
		elseif self:IsHovered() then
			c = brighten(baseColor, 22)
		end
		draw.RoundedBox(radius or 6, 0, 0, w, h, c)
	end
end

local function styleClose(btn)
	btn:SetText("×")
	btn:SetFont("ProteusTickets.Title")
	btn:SetTextColor(Color(220, 220, 220))
	btn.Paint = function(self, w, h)
		local c = self:IsHovered() and Color(210, 55, 55) or Color(45, 45, 45)
		draw.RoundedBox(8, 0, 0, w, h, c)
	end
end

local function fadeIn(frame)
	frame:SetAlpha(0)
	frame:AlphaTo(255, 0.18, 0)
	local x, y = frame:GetPos()
	frame:SetPos(x, y + 18)
	frame:MoveTo(x, y, 0.2, 0, -1)
end

local function fadeOut(frame)
	if not IsValid(frame) or frame.Closing then return end
	frame.Closing = true
	local x, y = frame:GetPos()
	frame:AlphaTo(0, 0.16, 0, function(_, pnl)
		if IsValid(pnl) then pnl:Remove() end
	end)
	frame:MoveTo(x, y + 18, 0.16, 0, -1)
end

local function clearChildren(panel)
	if not IsValid(panel) then return end
	local target = panel
	if panel.GetCanvas then
		local canvas = panel:GetCanvas()
		if IsValid(canvas) then target = canvas end
	end
	for _, child in ipairs(target:GetChildren()) do
		if IsValid(child) then child:Remove() end
	end
end

local function styleScroll(scroll)
	local bar = scroll:GetVBar()
	bar:SetWide(8)
	bar.Paint = function(_, w, h)
		draw.RoundedBox(4, 2, 2, w - 4, h - 4, Color(18, 18, 18))
	end
	bar.btnGrip.Paint = function(self, w, h)
		local c = self:IsHovered() and brighten(Config.AccentColor, 24) or Config.AccentColor
		draw.RoundedBox(4, 1, 0, w - 2, h, c)
	end
	bar.btnUp.Paint = function() end
	bar.btnDown.Paint = function() end
end

local function makeFrame(title, w, h)
	local frame = vgui.Create("DFrame")
	frame:SetSize(w, h)
	frame:Center()
	frame:SetTitle("")
	frame:ShowCloseButton(false)
	frame:SetDraggable(true)
	frame:MakePopup()
	frame.Paint = function(_, pw, ph)
		draw.RoundedBox(10, 0, 0, pw, ph, THEME.bg)
		draw.RoundedBoxEx(10, 0, 0, pw, 44, THEME.header, true, true, false, false)
		draw.RoundedBox(0, 0, 43, pw, 1, THEME.line)
		draw.SimpleText(title, "ProteusTickets.Title", 16, 22, THEME.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	local close = vgui.Create("DButton", frame)
	close:SetSize(34, 30)
	close:SetPos(w - 44, 7)
	styleClose(close)
	close.DoClick = function()
		fadeOut(frame)
	end
	frame.OnClose = function()
		gui.EnableScreenClicker(false)
	end
	fadeIn(frame)
	return frame
end

local function styleEntry(entry)
	entry:SetFont("ProteusTickets.Text")
	entry:SetTextColor(THEME.text)
	entry:SetPlaceholderColor(Color(120, 120, 120))
	entry:SetCursorColor(Config.AccentColor)
	entry.Paint = function(self, w, h)
		draw.RoundedBox(7, 0, 0, w, h, THEME.field)
		draw.RoundedBox(7, 0, 0, w, 1, Color(55, 55, 55))
		self:DrawTextEntryText(THEME.text, Config.AccentColor, THEME.text)
	end
end

local function addLabel(parent, text)
	local label = vgui.Create("DLabel", parent)
	label:Dock(TOP)
	label:DockMargin(2, 0, 0, 7)
	label:SetFont("ProteusTickets.FormLabel")
	label:SetText(text)
	label:SetTextColor(THEME.text)
	return label
end

local function addEntry(parent, placeholder, tall, multiline)
	local entry = vgui.Create("DTextEntry", parent)
	entry:Dock(TOP)
	entry:DockMargin(0, 0, 0, 12)
	entry:SetTall(tall)
	entry:SetPlaceholderText(placeholder)
	entry:SetMultiline(multiline and true or false)
	styleEntry(entry)
	return entry
end

local function addReadField(parent, labelText, value, tall)
	addLabel(parent, labelText)
	local box = vgui.Create("DTextEntry", parent)
	box:Dock(TOP)
	box:SetTall(tall)
	box:DockMargin(0, 0, 10, 16)
	box:SetMultiline(true)
	box:SetEditable(false)
	box:SetText(value or "")
	styleEntry(box)
	return box
end

function PROTEUS_TICKETS.OpenPlayerMenu(prefill)
	if IsValid(state.playerFrame) then fadeOut(state.playerFrame) end

	local frame = makeFrame("Nouveau ticket", 590, 620)
	state.playerFrame = frame

	local body = vgui.Create("DPanel", frame)
	body:Dock(FILL)
	body:DockMargin(14, 58, 14, 14)
	body.Paint = paintBox(THEME.panel, 8)
	body:DockPadding(0, 0, 0, 0)

	local bottom = vgui.Create("DPanel", body)
	bottom:Dock(BOTTOM)
	bottom:SetTall(58)
	bottom:DockPadding(14, 10, 14, 10)
	bottom.Paint = function(_, w, h)
		draw.RoundedBoxEx(8, 0, 0, w, h, THEME.panel2, false, false, true, true)
		draw.RoundedBox(0, 0, 0, w, 1, THEME.line)
	end

	local send = vgui.Create("DButton", bottom)
	send:Dock(RIGHT)
	send:SetWide(180)
	send:SetText("Envoyer le formulaire")
	styleButton(send, Config.AccentColor, 8)

	local cancel = vgui.Create("DButton", bottom)
	cancel:Dock(RIGHT)
	cancel:DockMargin(0, 0, 10, 0)
	cancel:SetWide(100)
	cancel:SetText("Annuler")
	styleButton(cancel, Color(70, 70, 70), 8)
	cancel.DoClick = function()
		fadeOut(frame)
	end

	local scroll = vgui.Create("DScrollPanel", body)
	scroll:Dock(FILL)
	scroll:DockPadding(14, 14, 14, 14)
	styleScroll(scroll)

	local intro = vgui.Create("DLabel", scroll)
	intro:Dock(TOP)
	intro:DockMargin(0, 0, 8, 16)
	intro:SetFont("ProteusTickets.Text")
	intro:SetText("Remplis ce carnet avec le maximum d'informations pour aider le staff à traiter ton ticket.")
	intro:SetTextColor(THEME.text)
	intro:SetWrap(true)
	intro:SetAutoStretchVertical(true)

	addLabel(scroll, "Décrivez votre Problème")
	local issue = addEntry(scroll, "Exemple : Problème avec un joueur, bug, question staff...", 40, false)
	issue:DockMargin(0, 0, 8, 18)

	addLabel(scroll, "Description de la situation")
	local situation = addEntry(scroll, "Explique clairement ce qu'il s'est passé, où, quand et comment.", 135, true)
	situation:DockMargin(0, 0, 8, 18)

	addLabel(scroll, "Personne impliquée / SteamID")
	local involved = addEntry(scroll, "Pseudo, SteamID, SteamID64 ou toute information utile.", 74, true)
	involved:DockMargin(0, 0, 8, 18)

	addLabel(scroll, "Informations supplémentaires")
	local extra = addEntry(scroll, "Ajoute les preuves, témoins, détails ou contexte important.", 120, true)
	extra:DockMargin(0, 0, 8, 8)

	if prefill and prefill ~= "" then
		issue:SetText(prefill)
	end

	send.DoClick = function()
		local i = string.Trim(issue:GetValue())
		local s = string.Trim(situation:GetValue())
		local p = string.Trim(involved:GetValue())
		local e = string.Trim(extra:GetValue())
		if i == "" or s == "" then
			chat.AddText(Config.TagColor, Config.ChatTag .. " ", Color(230, 85, 85), "Le problème et la description sont obligatoires.")
			return
		end
		net.Start("proteus_tickets_submit")
		net.WriteString(i)
		net.WriteString(s)
		net.WriteString(p)
		net.WriteString(e)
		net.SendToServer()
		fadeOut(frame)
	end
end

local function buildDetail()
	if not IsValid(state.frame) then return end
	local detail = state.frame.Detail
	local actions = state.frame.Actions
	clearChildren(detail)
	clearChildren(actions)

	local ticket = state.selected and findTicket(state.selected)

	if not ticket then
		local empty = vgui.Create("DLabel", detail)
		empty:Dock(FILL)
		empty:SetContentAlignment(5)
		empty:SetFont("ProteusTickets.Text")
		empty:SetText("Sélectionne un ticket dans la liste.")
		empty:SetTextColor(THEME.dim)
		return
	end

	local statusColor = Config.StatusColors[ticket.status] or THEME.text

	local header = vgui.Create("DPanel", detail)
	header:Dock(TOP)
	header:SetTall(92)
	header:DockMargin(0, 0, 10, 16)
	header.Paint = function(_, w, h)
		draw.RoundedBox(8, 0, 0, w, h, THEME.panel2)
		draw.RoundedBoxEx(8, 0, 0, 5, h, statusColor, true, false, true, false)
		draw.SimpleText("Ticket #" .. ticket.id, "ProteusTickets.Header", 16, 20, THEME.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(PROTEUS_TICKETS.StatusLabel(ticket.status), "ProteusTickets.Small", w - 18, 20, statusColor, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		draw.SimpleText(ticket.issue or ticket.message or "Demande joueur", "ProteusTickets.Text", 16, 48, THEME.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	local presence = ticket.online and "en ligne" or "hors ligne"
	local subText = ticket.requesterName .. " • " .. presence .. " • ouvert depuis " .. PROTEUS_TICKETS.FormatDuration(ticket.ageSeconds)
	if ticket.claimedByName then
		subText = subText .. " • pris par " .. ticket.claimedByName
	end

	local sub = vgui.Create("DLabel", header)
	sub:Dock(BOTTOM)
	sub:DockMargin(16, 0, 16, 10)
	sub:SetFont("ProteusTickets.Small")
	sub:SetText(subText)
	sub:SetTextColor(THEME.dim)

	addReadField(detail, "Problème", ticket.issue or ticket.message or "", 48)
	addReadField(detail, "Description de la situation", ticket.situation or ticket.message or "", 110)
	addReadField(detail, "Personne impliquée / SteamID", ticket.involved or "Non renseigné", 72)
	addReadField(detail, "Informations supplémentaires", ticket.extra or "Non renseigné", 92)

	addLabel(detail, "Échanges")

	local transcript = vgui.Create("DTextEntry", detail)
	transcript:Dock(TOP)
	transcript:SetTall(170)
	transcript:DockMargin(0, 0, 10, 14)
	transcript:SetMultiline(true)
	transcript:SetEditable(false)
	styleEntry(transcript)

	local lines = {}
	for _, reply in ipairs(ticket.replies or {}) do
		local who = reply.staff and ("[Staff] " .. reply.authorName) or reply.authorName
		lines[#lines + 1] = who .. " : " .. reply.text
	end
	if ticket.status == "closed" then
		lines[#lines + 1] = "[ Ticket fermé : " .. (ticket.closeReason or "") .. " ]"
	end
	transcript:SetText(table.concat(lines, "\n"))

	local replyEntry = vgui.Create("DTextEntry", actions)
	replyEntry:Dock(TOP)
	replyEntry:SetTall(34)
	replyEntry:DockMargin(12, 10, 12, 8)
	replyEntry:SetPlaceholderText("Réponse au joueur ou motif de fermeture")
	styleEntry(replyEntry)

	local row = vgui.Create("DPanel", actions)
	row:Dock(FILL)
	row:DockMargin(12, 0, 12, 10)
	row.Paint = nil

	local function makeButton(label, color, onClick)
		local b = vgui.Create("DButton", row)
		b:Dock(LEFT)
		b:DockMargin(0, 0, 8, 0)
		b:SetWide(104)
		b:SetText(label)
		styleButton(b, color, 7)
		b.DoClick = onClick
		return b
	end

	local claimBtn = makeButton("Prendre", Config.StatusColors.claimed, function()
		sendAction("claim", ticket.id, "")
	end)
	local gotoBtn = makeButton("Aller", Config.AccentColor, function()
		sendAction("goto", ticket.id, "")
	end)
	local bringBtn = makeButton("Amener", Config.AccentColor, function()
		sendAction("bring", ticket.id, "")
	end)
	local replyBtn = makeButton("Répondre", Config.AccentColor, function()
		local text = string.Trim(replyEntry:GetValue())
		if text == "" then return end
		sendAction("reply", ticket.id, text)
		replyEntry:SetText("")
	end)
	local closeBtn = makeButton("Fermer", Config.StatusColors.closed, function()
		sendAction("close", ticket.id, string.Trim(replyEntry:GetValue()))
	end)

	if ticket.status == "claimed" then
		claimBtn:SetEnabled(false)
	end
	if ticket.status == "closed" then
		claimBtn:SetEnabled(false)
		replyBtn:SetEnabled(false)
		closeBtn:SetEnabled(false)
	end
	if not ticket.online then
		gotoBtn:SetEnabled(false)
		bringBtn:SetEnabled(false)
	end
end

local function refreshList()
	if not IsValid(state.frame) then return end
	local list = state.frame.List
	clearChildren(list)

	if #state.data <= 0 then
		local empty = vgui.Create("DLabel", list)
		empty:Dock(TOP)
		empty:DockMargin(0, 18, 8, 0)
		empty:SetTall(28)
		empty:SetFont("ProteusTickets.Text")
		empty:SetText("Aucun ticket disponible.")
		empty:SetTextColor(THEME.dim)
		empty:SetContentAlignment(5)
		return
	end

	for _, ticket in ipairs(state.data) do
		local statusColor = Config.StatusColors[ticket.status] or THEME.dim
		local row = vgui.Create("DButton", list)
		row:Dock(TOP)
		row:DockMargin(0, 0, 8, 8)
		row:SetTall(72)
		row:SetText("")
		row.ticketId = ticket.id
		row.Paint = function(self, w, h)
			local selected = state.selected == ticket.id
			local c = selected and THEME.panel2 or THEME.panel3
			if self:IsHovered() and not selected then c = THEME.buttonHover end
			draw.RoundedBox(8, 0, 0, w, h, c)
			draw.RoundedBoxEx(8, 0, 0, 4, h, statusColor, true, false, true, false)
			draw.SimpleText("#" .. ticket.id .. "  " .. (ticket.issue or "Ticket"), "ProteusTickets.RowTitle", 14, 17, THEME.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(ticket.requesterName or "Joueur", "ProteusTickets.RowSmall", 14, 39, THEME.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(PROTEUS_TICKETS.StatusLabel(ticket.status), "ProteusTickets.RowSmall", w - 12, 17, statusColor, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			draw.SimpleText(PROTEUS_TICKETS.FormatDuration(ticket.ageSeconds), "ProteusTickets.RowSmall", w - 12, 39, THEME.dim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
		row.DoClick = function()
			state.selected = row.ticketId
			refreshList()
			buildDetail()
		end
	end
end

local function buildAdminFrame()
	if IsValid(state.frame) then fadeOut(state.frame) end

	local frame = makeFrame("Proteus Tickets", 930, 610)
	state.frame = frame

	frame.Paint = function(_, w, h)
		draw.RoundedBox(10, 0, 0, w, h, THEME.bg)
		draw.RoundedBoxEx(10, 0, 0, w, 50, THEME.header, true, true, false, false)
		draw.RoundedBox(0, 0, 49, w, 1, THEME.line)
		draw.SimpleText("Proteus Tickets", "ProteusTickets.Title", 16, 25, THEME.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(#state.data .. " ticket(s)", "ProteusTickets.Small", w - 132, 25, THEME.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	local body = vgui.Create("DPanel", frame)
	body:Dock(FILL)
	body:DockMargin(12, 62, 12, 12)
	body.Paint = nil

	local left = vgui.Create("DPanel", body)
	left:Dock(LEFT)
	left:SetWide(330)
	left:DockMargin(0, 0, 10, 0)
	left.Paint = paintBox(THEME.panel, 8)
	left:DockPadding(10, 10, 10, 10)

	local leftTitle = vgui.Create("DLabel", left)
	leftTitle:Dock(TOP)
	leftTitle:SetTall(28)
	leftTitle:SetFont("ProteusTickets.FormLabel")
	leftTitle:SetText("Tickets")
	leftTitle:SetTextColor(THEME.text)

	local refreshBtn = vgui.Create("DButton", left)
	refreshBtn:Dock(BOTTOM)
	refreshBtn:DockMargin(0, 8, 0, 0)
	refreshBtn:SetTall(34)
	refreshBtn:SetText("Rafraîchir")
	styleButton(refreshBtn, Config.AccentColor, 8)
	refreshBtn.DoClick = function()
		state.selected = nil
		state.lastTarget = 0
		state.data = {}
		refreshList()
		buildDetail()
		net.Start("proteus_tickets_refresh")
		net.SendToServer()
	end

	local listScroll = vgui.Create("DScrollPanel", left)
	listScroll:Dock(FILL)
	listScroll:DockMargin(0, 4, 0, 0)
	styleScroll(listScroll)
	frame.List = listScroll

	local right = vgui.Create("DPanel", body)
	right:Dock(FILL)
	right.Paint = paintBox(THEME.panel, 8)
	right:DockPadding(0, 0, 0, 0)

	local actions = vgui.Create("DPanel", right)
	actions:Dock(BOTTOM)
	actions:SetTall(92)
	actions.Paint = function(_, w, h)
		draw.RoundedBoxEx(8, 0, 0, w, h, THEME.panel2, false, false, true, true)
		draw.RoundedBox(0, 0, 0, w, 1, THEME.line)
	end
	frame.Actions = actions

	local detailScroll = vgui.Create("DScrollPanel", right)
	detailScroll:Dock(FILL)
	detailScroll:DockPadding(12, 12, 12, 12)
	styleScroll(detailScroll)

	local detail = vgui.Create("DPanel", detailScroll)
	detail:Dock(TOP)
	detail:SetTall(650)
	detail.Paint = nil
	detail.PerformLayout = function(self)
		local total = 0
		for _, child in ipairs(self:GetChildren()) do
			local _, y = child:GetPos()
			total = math.max(total, y + child:GetTall() + 12)
		end
		self:SetTall(math.max(total, detailScroll:GetTall()))
	end
	frame.Detail = detail

	refreshList()
	if state.lastTarget and state.lastTarget > 0 and findTicket(state.lastTarget) then
		state.selected = state.lastTarget
	end
	buildDetail()
end

local alerts = {}
local clickerUntil = 0

local function layoutAlerts()
	local y = ScrH() * 0.16
	for _, pnl in ipairs(alerts) do
		if IsValid(pnl) then
			pnl:MoveTo(ScrW() - pnl:GetWide() - 18, y, 0.18, 0, -1)
			y = y + pnl:GetTall() + 10
		end
	end
end

local function removeAlert(panel)
	for k, pnl in ipairs(alerts) do
		if pnl == panel then
			table.remove(alerts, k)
			break
		end
	end
	if IsValid(panel) then
		panel:AlphaTo(0, 0.15, 0, function(_, p)
			if IsValid(p) then p:Remove() end
		end)
	end
	layoutAlerts()
end

local function createAlert(id, who, issue)
	local duration = 10
	local start = CurTime()
	local panel = vgui.Create("EditablePanel")
	panel:SetSize(330, 118)
	panel:SetMouseInputEnabled(true)
	panel:SetKeyboardInputEnabled(false)
	panel:SetPos(ScrW() + 360, ScrH() * 0.16)
	panel:SetAlpha(0)
	panel.ticketId = id
	panel.Paint = function(_, w, h)
		local frac = math.Clamp((CurTime() - start) / duration, 0, 1)
		draw.RoundedBox(14, 0, 0, w, h, THEME.black)
		draw.SimpleText("Nouveau ticket #" .. id, "ProteusTickets.Header", 16, 17, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(who, "ProteusTickets.Small", 16, 41, THEME.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(string.sub(issue or "Demande joueur", 1, 70), "ProteusTickets.Small", 16, 62, Color(210, 210, 210), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText("Appuie sur F3 pour cliquer", "ProteusTickets.Small", 16, 84, Color(145, 145, 145), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.RoundedBox(6, w - 10, 10 + (h - 20) * frac, 4, (h - 20) * (1 - frac), Config.AccentColor)
	end

	local btn = vgui.Create("DButton", panel)
	btn:SetPos(174, 79)
	btn:SetSize(138, 28)
	btn:SetText("Aller vers le Ticket")
	styleButton(btn, Config.AccentColor, 7)
	btn.DoClick = function()
		sendJump(id)
		removeAlert(panel)
		gui.EnableScreenClicker(false)
	end

	table.insert(alerts, panel)
	panel:AlphaTo(255, 0.18, 0)
	layoutAlerts()
	timer.Simple(duration, function()
		if IsValid(panel) then removeAlert(panel) end
	end)
end

hook.Add("PlayerButtonDown", "proteus_tickets_alert_clicker", function(_, button)
	if button ~= KEY_F3 then return end
	for _, pnl in ipairs(alerts) do
		if IsValid(pnl) then
			clickerUntil = CurTime() + 10
			gui.EnableScreenClicker(true)
			return
		end
	end
end)

hook.Add("Think", "proteus_tickets_alert_clicker_timeout", function()
	if clickerUntil > 0 and CurTime() > clickerUntil then
		clickerUntil = 0
		gui.EnableScreenClicker(false)
	end
end)

net.Receive("proteus_tickets_player_menu", function()
	local prefill = net.ReadString()
	PROTEUS_TICKETS.OpenPlayerMenu(prefill)
end)

net.Receive("proteus_tickets_panel", function()
	local doOpen = net.ReadBool()
	state.data = util.JSONToTable(net.ReadString()) or {}
	state.lastTarget = net.ReadUInt(32) or 0
	if state.lastTarget > 0 then
		state.selected = state.lastTarget
	end
	if doOpen then
		buildAdminFrame()
	elseif IsValid(state.frame) then
		refreshList()
		buildDetail()
	end
end)

net.Receive("proteus_tickets_alert", function()
	local id = net.ReadUInt(32)
	local who = net.ReadString()
	local issue = net.ReadString()
	surface.PlaySound(Config.NotifySound)
	createAlert(id, who, issue)
end)
